package _08_mix;

public class _02_middle02 {
	
	//2. 1. 길이가 12인 char 배열을 선언하고 {'b', 'c', 's', 'i', 'i', 'o', 'q', 'n', 't', 'm', 'l', 't'}로 초기화합니다.
//	   단어를 bit, com, sql, int로 만들어서 모두 출력하세요.bit => 0, 4, 8 com => 1, 5, 9 sql => 2, 6, 10 int => 3, 7, 11
	
	
	public static void main(String[] args) {
		
		char[] cha = {'b', 'c', 's', 'i', 'i', 'o', 'q', 'n', 't', 'm', 'l', 't'};
		
		System.out.println();
		
		
		
//		3. 처음에 은행에 맡긴 돈은 10000원입니다
//		   금리는 연 10%입니다
//		   복리이자로 계산했을 때 10년후 얼마가 될까요?
	}

}
